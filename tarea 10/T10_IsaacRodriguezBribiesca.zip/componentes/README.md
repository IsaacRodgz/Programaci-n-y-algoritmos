# Tarea 10. Connected components

## Ejecución

> make && ./runTest image.pgm

## Compilado con

* gcc (Ubuntu 5.4.0-6ubuntu1~16.04.11) 5.4.0 20160609
