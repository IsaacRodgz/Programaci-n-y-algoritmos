# Tarea 10. Naive Bayes

## Ejecución

* Eval function
> make && ./runTest "spam.csv"

* predict function
> make && ./runTest "spam.csv" email

where email is an string with an example email that we want to classify

## Compilado con

* gcc (Ubuntu 5.4.0-6ubuntu1~16.04.11) 5.4.0 20160609
